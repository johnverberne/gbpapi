#!/bin/bash

#https://github.com/containous/traefik-library-image

#docker network create web

#https://tks.captainjohn.nl/api/doc

docker run -d -p 9090:9090 -p 80:80 -p 443:443 \
-v $PWD/traefik.toml:/etc/traefik/traefik.toml \
-v $PWD/acme.json:/acme.json \
-v /var/run/docker.sock:/var/run/docker.sock \
-l traefik.frontend.rule=Host:gbp.captainjohn.nl \
-l traefik.port=8080 \
--network web \
--name traefik-proxy \
traefik:v1.7


